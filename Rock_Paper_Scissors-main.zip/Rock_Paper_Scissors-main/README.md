This is Rock, Paper, Scissors game that i made using Javascript, CSS and HTML.
It is an Interactive game that can be played by both keyboard and mouse.
